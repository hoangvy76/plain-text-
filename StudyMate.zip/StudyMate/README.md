# StudyMate
Website dashboard hỗ trợ sinh viên quản lý lịch học, nhiệm vụ, deadline và tiến độ.

## Chạy thử
Mở file `index.html` bằng Chrome/Edge.

## Tính năng
- Dashboard tổng quan
- Lịch học
- Quản lý nhiệm vụ
- Deadline
- Biểu đồ thời gian học
- Dark mode
- Lưu nhiệm vụ bằng LocalStorage
- Responsive cho điện thoại

Có thể đưa thư mục này lên GitHub rồi deploy bằng Vercel.
